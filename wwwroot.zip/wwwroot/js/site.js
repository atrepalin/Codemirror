﻿function rotate(element, degrees) {
    element.css({
        '-webkit-transform': 'rotate(' + degrees + 'deg)',
        '-moz-transform': 'rotate(' + degrees + 'deg)',
        '-ms-transform': 'rotate(' + degrees + 'deg)',
        'transform': 'rotate(' + degrees + 'deg)'
    });
    return element;
};

function getElement(selector) {
    var element = $("iframe").contents().find(selector).length;
    if (element > 0)
        return $("iframe").contents().find(selector);
    else
        return $(selector);
};

function debug() {
    $("div[id=debug]").slideToggle("fast");
};

function loadFile(filePath) {
    var result = null;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", filePath, false);
    xmlhttp.send();
    if (xmlhttp.status == 200) {
        result = xmlhttp.responseText;
    }
    return result;
}